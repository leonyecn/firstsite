# heading
Liyan Ye

# content

## p1:current situation
Hi, I'm Liyan.

I am pursuing my master degree in Digital Living, at the Department of Digital Design & Information Studies at the Aarhus University, Denmark. This program is mainly about how digital technologies are applied to our everyday life. **Here are some of my projects during the study.**

## p2:previous situation

Previously I have finished my M.Phil. Degree in Epistemology at Wuhan University, China. I focused on the Gettier Problem and the digital application of Public Sphere theory. **Please click here to check some of my papers and publications.**

And I also have a BA. in Chinese Language and Literature. I started to do some ethnographic analysis and applied them with digital-related topics. I also began to write some technological commentaries and reviews. **Here are some of my early publications and awarded researches.**

## p3:part time

When I'm free from my study and work, I travel a lot, **take photos** and **write journals** all the way along. I'm also a **gym rat** and **game lover** at the same time :)